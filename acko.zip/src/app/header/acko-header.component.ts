import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'acko-header',
  templateUrl: './acko-header.component.html',
  styleUrls: ['./acko-header.component.css']
})
export class HeaderAckoHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
