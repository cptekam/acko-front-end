import { CustomerHistory } from './customer-history';

describe('CustomerHistory', () => {
  it('should create an instance', () => {
    expect(new CustomerHistory()).toBeTruthy();
  });
});
