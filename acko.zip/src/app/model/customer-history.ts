export class CustomerHistory {
    id:number;
    phoneNumber: number;
    insuranceTye: string;
    numberOfPolicies: number;
    totalAmount:  number;
    totalClaimInitiated: number;
    numberOfClaimsPaid: number;
    claimsPaidAmount: number;
}
